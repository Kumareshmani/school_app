// profile page 
/*
for both studetn and teacher
containes
user image in a circle icon
name
email - from firebase auth table
phone number 
dat of birth*/
//update profile button
/*
asks for password -> check auth password
make changes by enterying new data in a form
commit the changes in th3 respecgtive databases
*/
//sign out button