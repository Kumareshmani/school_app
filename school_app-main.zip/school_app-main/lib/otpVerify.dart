/*import 'package:flutter/material.dart';

class OTP_Verify extends StatefulWidget {
  const OTP_Verify({Key? key}) : super(key: key);

  @override
  State<OTP_Verify> createState() => _OTP_VerifyState();
}

class _OTP_VerifyState extends State<OTP_Verify> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          //otp verify code
          //confirmation
          //move to next screen -> login
        )));
  }
}
*/