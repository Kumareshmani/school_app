/*
home page with obly the classes made by tecaher and
 a button to navigate user to class link url(direct link to meet or zoom)
(new link field in added in the create class ...refer to it)
*/
//same as before data in stream builder needs to be sorted y start date
//classes past the end date shoud not be shown
//once a class is created, snack bar appears with calnedar options
//add class to calendar with reminder and notifications
